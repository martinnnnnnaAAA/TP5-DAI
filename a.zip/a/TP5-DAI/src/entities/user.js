class User {
    id;
    first_name;
    last_name;
    username;
    password;
}
export default {User};