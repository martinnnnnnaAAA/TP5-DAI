const config = {
    host : "localhost",
    database : "DB-tp5",
    user : "postgres",
    password : "root",
    port : 5432 
}
export default config;